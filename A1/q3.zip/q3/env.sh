#!/bin/bash
# env.sh - Environment setup for graph indexing
# Activates virtual environment

source .venv/bin/activate
