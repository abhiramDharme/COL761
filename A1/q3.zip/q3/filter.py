import sys
import numpy as np

if __name__ == "__main__":
    db_matrix = np.load(sys.argv[1])
    q_matrix = np.load(sys.argv[2])
    output_path = sys.argv[3]
    
    with open(output_path, 'w') as f:
        for i in range(len(q_matrix)):
            q_vec = q_matrix[i]
            # LOGIC: (DB & Q) == Q
            # Meaning: If Q has it, DB MUST have it.
            bitwise_and = np.bitwise_and(db_matrix, q_vec)
            matches = np.all(bitwise_and == q_vec, axis=1)
            candidates = np.where(matches)[0]
            
            f.write(f"q # {i}\n")
            f.write(f"c # {' '.join(map(str, candidates))}\n")