import networkx as nx

def parse_dataset(filepath):
    graphs = []
    current_graph = None
    graph_id = 0
    with open(filepath, 'r') as f:
        for line in f:
            line = line.strip()
            if not line: continue
            if line.startswith('#'):
                if current_graph is not None: graphs.append(current_graph)
                current_graph = nx.Graph(id=graph_id)
                graph_id += 1
            elif line.startswith('v'):
                parts = line.split()
                current_graph.add_node(int(parts[1]), label=int(parts[2]))
            elif line.startswith('e'):
                parts = line.split()
                u, v, label = int(parts[1]), int(parts[2]), int(parts[3])
                # STRICT DE-DUPLICATION (TA Requirement)
                if not current_graph.has_edge(u, v):
                    current_graph.add_edge(u, v, label=label)
    if current_graph is not None: graphs.append(current_graph)
    return graphs

def parse_gspan_output(filepath):
    patterns = []
    current_graph = None
    with open(filepath, 'r') as f:
        for line in f:
            line = line.strip()
            if not line: continue
            if line.startswith('t #'):
                if current_graph is not None: patterns.append(current_graph)
                current_graph = nx.Graph()
            elif line.startswith('v'):
                parts = line.split()
                current_graph.add_node(int(parts[1]), label=int(parts[2]))
            elif line.startswith('e'):
                parts = line.split()
                current_graph.add_edge(int(parts[1]), int(parts[2]), label=int(parts[3]))
    if current_graph is not None: patterns.append(current_graph)
    return patterns