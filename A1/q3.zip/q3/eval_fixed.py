import sys

def parse_truth_file(filepath):
    """
    Parses truth file. Handles two formats:
    1. ID: 1,2,3...
    2. q # ID \n c # 1 2 3...
    """
    results = {}
    with open(filepath, 'r') as f:
        content = f.read()
        
    if 'q #' in content:
        # Standard format
        current_q = None
        for line in content.splitlines():
            line = line.strip()
            if not line: continue
            if line.startswith('q #'):
                current_q = int(line.split('#')[1].strip())
            elif line.startswith('c #'):
                parts = line.split('#')[1].strip()
                results[current_q] = set(map(int, parts.split())) if parts else set()
    else:
        # Format: ID: 1,2,3
        for line in content.splitlines():
            line = line.strip()
            if not line: continue
            if ':' in line:
                q_id_str, cands_str = line.split(':', 1)
                q_id = int(q_id_str.strip())
                cands_str = cands_str.strip()
                if not cands_str:
                    results[q_id] = set()
                else:
                    results[q_id] = set(map(int, cands_str.replace(',', ' ').split()))
    return results

def main():
    if len(sys.argv) != 3:
        print("Usage: python evaluate_fixed.py <truth.dat> <candidates.txt>")
        sys.exit(1)

    # 1. Load Truth
    true_results = parse_truth_file(sys.argv[1])
    
    # 2. Load Candidates
    candidate_results = parse_truth_file(sys.argv[2])

    if not true_results:
        print("Error: Ground truth file is empty or in unknown format.")
        return

    total_score = 0
    valid_submission = True
    queries_evaluated = 0

    print(f"{'Q_ID':<5} | {'True':<5} | {'Cand':<5} | {'Prec':<5}")
    print("-" * 30)

    for q_idx in sorted(true_results.keys()):
        R_q = true_results[q_idx]
        C_q = candidate_results.get(q_idx, set())
        
        # Check for False Negatives
        missing = R_q - C_q
        if missing:
            print(f"FAIL: Q{q_idx} missed {len(missing)} true graphs (First few: {list(missing)[:5]})")
            valid_submission = False
        
        if len(C_q) == 0:
            score = 1.0 if len(R_q) == 0 else 0.0
        else:
            intersection = R_q & C_q
            score = len(intersection) / len(C_q)
            
        print(f"{q_idx:<5} | {len(R_q):<5} | {len(C_q):<5} | {score:.4f}")
        total_score += score
        queries_evaluated += 1

    avg = total_score / queries_evaluated if queries_evaluated else 0
    print("="*30)
    print(f"AVG PRECISION: {avg:.5f}")
    if not valid_submission:
        print("STATUS: INVALID (False Negatives Detected)")
    else:
        print("STATUS: VALID (No False Negatives)")

if __name__ == "__main__":
    main()
